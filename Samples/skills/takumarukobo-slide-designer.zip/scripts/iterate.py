# takumarukobo-slide-designer
"""Loop harness: generate from a free spec, then evaluate. Prints per-slide
verdict + feedback. The revision step (edit spec per feedback) is done by the
model between runs — quality is enforced by the evaluator, not templates."""
import argparse, subprocess, sys, os
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input", required=True); ap.add_argument("--output", required=True)
    a=ap.parse_args(); here=os.path.dirname(__file__)
    subprocess.run([sys.executable, os.path.join(here,"generate_presentation.py"),
                    "--input",a.input,"--output",a.output], check=True)
    subprocess.run([sys.executable, os.path.join(here,"evaluate.py"),
                    a.output,"--spec",a.input])
if __name__=="__main__": main()
