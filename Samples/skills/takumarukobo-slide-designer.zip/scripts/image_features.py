# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""Evaluate slides by how they LOOK (B-1): render the pptx to an image and
measure interpretable, human-meaningful features. No box metadata — this reads
the rendered pixels, the same thing a person sees.

Features (all 0..1 unless noted), each chosen to be explainable so the evaluator
can give concrete feedback:
  ink_coverage    : fraction of non-background pixels (how "full" the slide is)
  whitespace_max  : largest empty rectangle / slide area (big blank gap = bad)
  region_count    : distinct content blobs (≈ number of information units), 0..1 scaled
  edge_density    : fraction of edge pixels (fine detail: charts/icons/dense text)
  color_count     : distinct prominent hues, scaled (0..1)
  colorfulness    : Hasler-Susstrunk colorfulness, scaled
  contrast        : std of luminance on ink (readability)
  text_area_ratio : small-component area / ink area (how text-heavy vs figure)
  figure_ratio    : large-solid-region area / ink area (charts/blocks/pictograms)
  balance         : 1 - |mass asymmetry| across left/right & top/bottom
  h_symmetry      : left-right mirror similarity (0..1)
"""
from __future__ import annotations
import os, subprocess, tempfile, math
import numpy as np
from PIL import Image


def render_pptx_page(pptx_path, page=1, dpi=110):
    import shutil as _sh
    # Preferred: LibreOffice (best fidelity). Fallback: pure-python renderer.
    if _sh.which("libreoffice") is None and _sh.which("soffice") is None:
        try:
            import render_pptx
            return render_pptx.render_to_file(pptx_path, page)
        except Exception:
            raise FileNotFoundError("libreoffice not found and pure-python render failed")
    if _sh.which("pdftoppm") is None:
        try:
            import render_pptx
            return render_pptx.render_to_file(pptx_path, page)
        except Exception:
            raise FileNotFoundError("pdftoppm (poppler-utils) not found")
    out = tempfile.mkdtemp()
    subprocess.run(["libreoffice", "--headless", "--convert-to", "pdf",
                    "--outdir", out, pptx_path],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=200)
    pdf = os.path.join(out, os.path.splitext(os.path.basename(pptx_path))[0] + ".pdf")
    if not os.path.exists(pdf):
        return None
    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), "-f", str(page), "-l", str(page),
                    pdf, os.path.join(out, "pg")],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    for fn in sorted(os.listdir(out)):
        if fn.startswith("pg") and fn.endswith(".png"):
            return os.path.join(out, fn)
    return None


def _largest_empty_fraction(occ):
    """Largest all-empty axis-aligned rectangle area / total (histogram method)."""
    H, W = occ.shape
    empty = (~occ).astype(np.int32)
    height = np.zeros(W, dtype=np.int32); best = 0
    for r in range(H):
        height = np.where(empty[r] == 1, height + 1, 0)
        stack = []; i = 0
        hh = list(height) + [0]
        while i < len(hh):
            if not stack or hh[i] >= hh[stack[-1]]:
                stack.append(i); i += 1
            else:
                top = stack.pop()
                w = i if not stack else i - stack[-1] - 1
                best = max(best, hh[top] * w)
    return best / (H * W)


def _regions(occ):
    """Count connected content blobs (4-connectivity), ignore tiny specks."""
    H, W = occ.shape
    lbl = np.zeros((H, W), dtype=np.int32); cur = 0; sizes = []
    for r in range(H):
        for c in range(W):
            if occ[r, c] and lbl[r, c] == 0:
                cur += 1; stack = [(r, c)]; lbl[r, c] = cur; sz = 0
                while stack:
                    y, x = stack.pop(); sz += 1
                    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        ny, nx = y + dy, x + dx
                        if 0 <= ny < H and 0 <= nx < W and occ[ny, nx] and lbl[ny, nx] == 0:
                            lbl[ny, nx] = cur; stack.append((ny, nx))
                sizes.append(sz)
    thr = 0.0008 * H * W
    return [s for s in sizes if s >= thr]


def extract(pptx_path, page=1):
    img_path = render_pptx_page(pptx_path, page)
    if img_path is None:
        return None
    return extract_image(img_path)


def extract_image(img_or_path):
    im = (Image.open(img_or_path) if isinstance(img_or_path, str) else img_or_path).convert("RGB")
    im.thumbnail((480, 480))
    a = np.asarray(im).astype(np.float32)
    H, W, _ = a.shape
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    # background = the dominant near-uniform corner colour (usually white)
    bg = np.median(np.concatenate([a[:5, :5].reshape(-1, 3), a[:5, -5:].reshape(-1, 3),
                                   a[-5:, :5].reshape(-1, 3), a[-5:, -5:].reshape(-1, 3)]), axis=0)
    dist = np.sqrt(((a - bg) ** 2).sum(axis=2))
    ink = dist > 28                                   # non-background pixels
    ink_cov = float(ink.mean())
    # coarse occupancy grid for whitespace & regions
    gs = 48
    occ = np.zeros((gs, gs), dtype=bool)
    for i in range(gs):
        for j in range(gs):
            y0, y1 = int(i * H / gs), int((i + 1) * H / gs)
            x0, x1 = int(j * W / gs), int((j + 1) * W / gs)
            occ[i, j] = ink[y0:y1, x0:x1].mean() > 0.06
    whitespace_max = _largest_empty_fraction(occ)
    regions = _regions(occ)
    region_count = min(1.0, len(regions) / 30.0)
    # edges (Sobel-ish) -> detail density
    gy = np.abs(np.diff(lum, axis=0, prepend=lum[:1]))
    gx = np.abs(np.diff(lum, axis=1, prepend=lum[:, :1]))
    edges = (gx + gy) > 40
    edge_density = float(edges.mean())
    # colour
    hsv = np.asarray(Image.fromarray(a.astype(np.uint8)).convert("HSV")).astype(np.float32)
    hue, sat = hsv[:, :, 0], hsv[:, :, 1] / 255.0
    sat_ink = sat[ink] if ink.any() else np.array([0.0])
    colored = ink & (sat > 0.18)
    hues = (hue[colored] / 255.0 * 12).astype(int) if colored.any() else np.array([], dtype=int)
    color_count = min(1.0, (len(np.unique(hues)) / 8.0)) if hues.size else 0.0
    rg = np.abs(r - g); yb = np.abs(0.5 * (r + g) - b)
    colorfulness = float(min(1.0, (np.sqrt(rg.std() ** 2 + yb.std() ** 2)
                                   + 0.3 * np.sqrt(rg.mean() ** 2 + yb.mean() ** 2)) / 120.0))
    contrast = float(min(1.0, (lum[ink].std() / 90.0))) if ink.any() else 0.0
    # text vs figure: small regions ~ text lines; big solid regions ~ blocks/figures
    tot = sum(regions) if regions else 1
    small = sum(s for s in regions if s < 0.004 * gs * gs)
    big = sum(s for s in regions if s > 0.02 * gs * gs)
    text_area_ratio = float(small / tot)
    figure_ratio = float(big / tot)
    # balance & symmetry
    ys, xs = np.where(ink)
    if xs.size:
        bx = abs(xs.mean() / W - 0.5) * 2; by = abs(ys.mean() / H - 0.5) * 2
        balance = float(1 - min(1.0, (bx + by) / 2))
    else:
        balance = 0.0
    left = ink[:, :W // 2]; right = np.fliplr(ink[:, W - W // 2:])
    m = min(left.shape[1], right.shape[1])
    h_symmetry = float((left[:, :m] == right[:, :m]).mean()) if m else 0.0
    return {"ink_coverage": round(ink_cov, 3), "whitespace_max": round(whitespace_max, 3),
            "region_count": round(region_count, 3), "edge_density": round(edge_density, 3),
            "color_count": round(color_count, 3), "colorfulness": round(colorfulness, 3),
            "contrast": round(contrast, 3), "text_area_ratio": round(text_area_ratio, 3),
            "figure_ratio": round(figure_ratio, 3), "balance": round(balance, 3),
            "h_symmetry": round(h_symmetry, 3)}


if __name__ == "__main__":
    import sys, json
    print(json.dumps(extract(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1),
                     ensure_ascii=False))
