# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""
Japanese text helpers for python-pptx.

Two problems this module solves:

1. East-Asian typeface.  python-pptx's ``run.font.name`` only writes the
   ``<a:latin>`` typeface.  If you leave ``<a:ea>`` unset, PowerPoint may fall
   back to a default gothic face for Japanese runs, which breaks a carefully
   chosen theme font.  ``apply_font`` writes ``latin``, ``ea`` and ``cs`` so a
   Japanese face (Meiryo / Yu Gothic / MS PGothic) renders consistently.

2. Inline emphasis.  Kasumigaseki ("Ponchi-e") slides rely heavily on red key
   terms, bold and underline inside otherwise plain text.  ``add_rich_text``
   parses a tiny markup and emits one run per styled segment:

       [[...]]  ->  emphasis colour (red key term)   + bold
       **...**  ->  bold
       __...__  ->  underline

   Markers do not nest; the earliest match wins.
"""

from __future__ import annotations

import re

from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
from pptx.util import Pt


_TOKEN = re.compile(r"(\[\[.+?\]\]|\*\*.+?\*\*|__.+?__)")


def apply_font(run, latin: str, ea: str | None = None, *,
               size=None, bold: bool | None = None,
               color: RGBColor | None = None,
               underline: bool | None = None) -> None:
    """Set latin + East-Asian + complex-script typeface on a run."""
    font = run.font
    font.name = latin  # writes <a:latin> and creates rPr
    if size is not None:
        font.size = size if hasattr(size, "emu") else Pt(size)
    if bold is not None:
        font.bold = bold
    if underline is not None:
        font.underline = underline
    if color is not None:
        font.color.rgb = color

    rPr = run._r.get_or_add_rPr()
    ea_face = ea or latin
    _ensure_child(rPr, "a:ea", after="a:latin").set("typeface", ea_face)
    _ensure_child(rPr, "a:cs", after="a:ea").set("typeface", latin)


def _ensure_child(rPr, tag: str, after: str):
    el = rPr.find(qn(tag))
    if el is None:
        el = rPr.makeelement(qn(tag), {})
        anchor = rPr.find(qn(after))
        if anchor is not None:
            anchor.addnext(el)
        else:
            rPr.append(el)
    return el


def _segments(text: str):
    """Yield (segment_text, bold, underline, emphasis) tuples."""
    pos = 0
    for m in _TOKEN.finditer(text):
        if m.start() > pos:
            yield text[pos:m.start()], False, False, False
        tok = m.group(0)
        if tok.startswith("[["):
            yield tok[2:-2], True, False, True
        elif tok.startswith("**"):
            yield tok[2:-2], True, False, False
        else:  # __
            yield tok[2:-2], False, True, False
        pos = m.end()
    if pos < len(text):
        yield text[pos:], False, False, False


def add_rich_text(paragraph, text: str, *, latin: str, ea: str,
                  size, base_color: RGBColor, emphasis_color: RGBColor,
                  bold: bool = False) -> None:
    """Append emphasis-aware runs to an (empty) paragraph."""
    any_run = False
    for seg, seg_bold, seg_ul, seg_emph in _segments(text):
        if seg == "":
            continue
        run = paragraph.add_run()
        run.text = seg
        apply_font(
            run, latin, ea,
            size=size,
            bold=bool(bold or seg_bold or seg_emph),
            underline=seg_ul or None,
            color=emphasis_color if seg_emph else base_color,
        )
        any_run = True
    if not any_run:  # keep an empty run so the paragraph still carries font
        run = paragraph.add_run()
        run.text = ""
        apply_font(run, latin, ea, size=size, color=base_color)


def strip_markup(text: str) -> str:
    """Plain text with markup removed (for width/length estimation)."""
    return "".join(seg for seg, *_ in _segments(text or ""))
