# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""Template-free slide generator.

There are NO fixed layouts, NO theme lock, NO chrome, NO icon set. A slide is a
free canvas: the caller places primitives (box / text / line / ellipse) at
relative (0..1) coordinates of the full slide, with free #hex colours. Quality is
NOT enforced by templates — it is judged afterwards by the learned evaluator
(evaluate.py + model.json). Generate freely → evaluate → fix → regenerate.

spec = {
  "slides": [
    {
      "bg": "#0f2438",                     # optional slide fill (#hex)
      "elements": [
        {"type":"box","x":0.05,"y":0.1,"w":0.4,"h":0.3,
         "fill":"#1a3c6e","border":"#1a3c6e","border_pt":1.2,
         "text":"...","color":"#ffffff","size":14,"bold":true,
         "align":"center","anchor":"middle"},
        {"type":"text","x":..,"y":..,"w":..,"h":..,"text":"...","size":24,...},
        {"type":"line","x1":..,"y1":..,"x2":..,"y2":..,
         "stroke":"#5e77a3","width":1.4,"arrow":true,"dashed":false},
        {"type":"ellipse", ...}                                  # like box
      ]
    }
  ]
}
"""
from __future__ import annotations

from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn

try:
    from jp_text import apply_font
except Exception:                                  # pragma: no cover
    def apply_font(run, latin, ea=None, **k):
        run.font.name = latin

_JP = "Meiryo"
_ALIGN = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}
_ANCHOR = {"top": MSO_ANCHOR.TOP, "middle": MSO_ANCHOR.MIDDLE, "bottom": MSO_ANCHOR.BOTTOM}


def _hex(c, default=None):
    if isinstance(c, RGBColor):
        return c
    if isinstance(c, str) and c.startswith("#"):
        h = c.lstrip("#")
        if len(h) == 3:
            h = "".join(x * 2 for x in h)
        if len(h) == 6:
            return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    return default


def _flatten(shape):
    """Remove theme style / shadow so the shape stays flat (evaluator requires)."""
    el = shape._element
    st = el.find(qn("p:style"))
    if st is not None:
        el.remove(st)
    try:
        shape.shadow.inherit = False
    except Exception:
        pass


def _text(shape_or_tf, text, size, color, bold, align, anchor):
    tf = shape_or_tf
    tf.word_wrap = True
    try:
        tf.vertical_anchor = anchor
    except Exception:
        pass
    tf.margin_left = tf.margin_right = Emu(36000)
    tf.margin_top = tf.margin_bottom = Emu(18000)
    first = True
    for line in str(text).split("\n"):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        r = p.add_run(); r.text = line
        r.font.size = Pt(size); r.font.bold = bold
        r.font.color.rgb = color
        apply_font(r, _JP, _JP)


class FreeEngine:
    def __init__(self):
        self.prs = Presentation()
        self.prs.slide_width = Inches_(13.333)
        self.prs.slide_height = Inches_(7.5)
        self.W = self.prs.slide_width
        self.H = self.prs.slide_height

    def _ax(self, v): return int(v * self.W)
    def _ay(self, v): return int(v * self.H)

    def add_slide(self, spec):
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[6])   # blank
        if spec.get("bg"):
            r = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, self.W, self.H)
            r.fill.solid(); r.fill.fore_color.rgb = _hex(spec["bg"], RGBColor(255, 255, 255))
            r.line.fill.background(); _flatten(r)
        for el in spec.get("elements", []):
            try:
                self._draw(slide, el)
            except Exception:
                pass
        return slide

    def _draw(self, slide, el):
        t = el.get("type", "box")
        align = _ALIGN.get(el.get("align", "left"), PP_ALIGN.LEFT)
        anchor = _ANCHOR.get(el.get("anchor", "middle"), MSO_ANCHOR.MIDDLE)
        color = _hex(el.get("color"), RGBColor(0x14, 0x20, 0x2f))
        if t == "line":
            cn = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                                            self._ax(el["x1"]), self._ay(el["y1"]),
                                            self._ax(el["x2"]), self._ay(el["y2"]))
            cn.line.color.rgb = _hex(el.get("stroke"), RGBColor(0x5e, 0x77, 0xa3))
            cn.line.width = Pt(el.get("width", 1.4))
            if el.get("dashed"):
                d = cn.line._get_or_add_ln(); pd = d.makeelement(qn("a:prstDash"), {"val": "dash"}); d.append(pd)
            if el.get("arrow"):
                ln = cn.line._get_or_add_ln()
                ln.append(ln.makeelement(qn("a:tailEnd"), {"type": "triangle", "w": "med", "len": "med"}))
            _flatten(cn)
            return
        if t == "text":
            tb = slide.shapes.add_textbox(self._ax(el["x"]), self._ay(el["y"]),
                                          self._ax(el["w"]), self._ay(el["h"]))
            _text(tb.text_frame, el.get("text", ""), el.get("size", 14), color,
                  bool(el.get("bold")), align, anchor)
            return
        mso = MSO_SHAPE.OVAL if t == "ellipse" else MSO_SHAPE.RECTANGLE
        sp = slide.shapes.add_shape(mso, self._ax(el["x"]), self._ay(el["y"]),
                                    self._ax(el["w"]), self._ay(el["h"]))
        fill = _hex(el.get("fill"))
        if fill is not None:
            sp.fill.solid(); sp.fill.fore_color.rgb = fill
        else:
            sp.fill.background()
        bd = el.get("border")
        if bd is False:
            sp.line.fill.background()
        else:
            sp.line.color.rgb = _hex(bd, RGBColor(0x1a, 0x3c, 0x6e))
            sp.line.width = Pt(el.get("border_pt", 1.0))
        _flatten(sp)
        if el.get("text"):
            _text(sp.text_frame, el["text"], el.get("size", 14), color,
                  bool(el.get("bold")), align, anchor)

    def anonymize(self):
        cp = self.prs.core_properties
        for a in ("author", "last_modified_by", "title", "subject", "category",
                  "comments", "keywords"):
            try:
                setattr(cp, a, "")
            except Exception:
                pass

    def save(self, path):
        self.anonymize()
        self.prs.save(path)


def Inches_(v):
    return Emu(int(v * 914400))


def build(spec, out_path):
    eng = FreeEngine()
    for s in spec.get("slides", []):
        eng.add_slide(s)
    eng.save(out_path)
    return len(spec.get("slides", []))
