# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""Pure-python pptx -> PIL image renderer (no LibreOffice / poppler).

Uses only python-pptx + Pillow, which are present in the target environment.
It is an APPROXIMATION of PowerPoint's rendering — good enough for the
interpretable "look" features (coverage, whitespace, edges from embedded
pictures, text, contrast). Embedded pictures (icons/charts/photos) are pasted at
their real positions, so figure/detail content is captured. Gradients, 3-D,
theme effects and real chart plotting are not reproduced.
"""
from __future__ import annotations
import io, os
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.util import Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.enum.text import PP_ALIGN

_FONTS = [
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJKjp-Regular.otf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "C:/Windows/Fonts/meiryo.ttc",
]
_FONT_CACHE = {}

def _font(size, bold=False):
    size = max(8, int(size))
    key = (size, bold)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    for p in _FONTS:
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, size); _FONT_CACHE[key] = f; return f
            except Exception:
                continue
    f = ImageFont.load_default(); _FONT_CACHE[key] = f; return f

def _rgb(color):
    try:
        if color and color.type is not None and color.rgb is not None:
            c = color.rgb
            return (c[0], c[1], c[2]) if not isinstance(c, str) else (
                int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16))
    except Exception:
        pass
    return None

def _fill_rgb(shape):
    try:
        fl = shape.fill
        if str(fl.type) == "MSO_FILL.SOLID" or getattr(fl, "type", None) == 1:
            return _rgb(fl.fore_color)
    except Exception:
        pass
    return None

def _line_rgb(shape):
    try:
        ln = shape.line
        c = _rgb(ln.color)
        return c
    except Exception:
        return None

def _draw_text(d, box, tf, scale):
    x, y, w, h = box
    cy = y + 4
    for para in tf.paragraphs:
        runs = para.runs or ([para] if para.text else [])
        txt = "".join(r.text for r in para.runs) if para.runs else para.text
        if not txt:
            cy += int(14 * scale * 1.4); continue
        sz = None; bold = False; col = (30, 30, 30)
        for r in para.runs:
            if r.font.size: sz = r.font.size.pt
            if r.font.bold: bold = True
            rc = _rgb(r.font.color)
            if rc: col = rc
        fs = (sz if sz else 14) * scale * 1.2
        font = _font(fs, bold)
        align = para.alignment
        # wrap
        maxw = max(10, w - 8)
        words = list(txt); line = ""; lines = []
        for ch in words:
            if d.textlength(line + ch, font=font) <= maxw:
                line += ch
            else:
                lines.append(line); line = ch
        if line: lines.append(line)
        for ln in lines:
            tw = d.textlength(ln, font=font)
            tx = x + 4
            if align == PP_ALIGN.CENTER: tx = x + (w - tw) / 2
            elif align == PP_ALIGN.RIGHT: tx = x + w - tw - 4
            d.text((tx, cy), ln, fill=col, font=font)
            cy += int(fs * 1.35)

def _shape(d, im, shape, scale, ox=0, oy=0):
    try:
        st = shape.shape_type
    except Exception:
        st = None
    try:
        x = int(shape.left or 0) * scale + ox; y = int(shape.top or 0) * scale + oy
        w = int(shape.width or 0) * scale; h = int(shape.height or 0) * scale
    except Exception:
        return
    box = (x, y, x + w, y + h)

    if st == MSO_SHAPE_TYPE.GROUP:
        for sub in shape.shapes:
            _shape(d, im, sub, scale, ox=x, oy=y)  # note: group child coords are relative; approx
        return
    if st == MSO_SHAPE_TYPE.PICTURE:
        try:
            blob = shape.image.blob
            pic = Image.open(io.BytesIO(blob)).convert("RGBA")
            pic = pic.resize((max(1, int(w)), max(1, int(h))))
            im.paste(pic, (int(x), int(y)), pic)
        except Exception:
            d.rectangle(box, fill=(230, 230, 230))
        return
    if st == MSO_SHAPE_TYPE.TABLE or shape.has_table if hasattr(shape, "has_table") else False:
        try:
            tbl = shape.table
            rows = len(tbl.rows); cols = len(tbl.columns)
            cw = w / cols; ch = h / rows
            for ri in range(rows):
                for ci in range(cols):
                    cx = x + ci * cw; cyy = y + ri * ch
                    d.rectangle([cx, cyy, cx + cw, cyy + ch], outline=(150, 150, 150))
                    cell = tbl.cell(ri, ci)
                    if cell.text_frame:
                        _draw_text(d, (cx, cyy, cw, ch), cell.text_frame, scale)
            return
        except Exception:
            pass
    if st == MSO_SHAPE_TYPE.LINE or (st is not None and "CONNECTOR" in str(st)):
        d.line([x, y, x + w, y + h], fill=_line_rgb(shape) or (90, 90, 90), width=2)
        return
    # generic autoshape / placeholder
    fill = _fill_rgb(shape)
    is_oval = False
    try:
        is_oval = "OVAL" in str(shape.auto_shape_type)
    except Exception:
        pass
    if fill is not None:
        (d.ellipse if is_oval else d.rectangle)(box, fill=fill)
    lc = _line_rgb(shape)
    if lc is not None:
        (d.ellipse if is_oval else d.rectangle)(box, outline=lc, width=2)
    if getattr(shape, "has_text_frame", False) and shape.text_frame.text.strip():
        _draw_text(d, (x, y, w, h), shape.text_frame, scale)

def render(pptx_path, page=1, target_w=1280):
    prs = Presentation(pptx_path)
    slides = list(prs.slides)
    if page < 1 or page > len(slides):
        return None
    sl = slides[page - 1]
    SW = int(prs.slide_width); SH = int(prs.slide_height)
    scale = target_w / SW
    W = target_w; H = int(SH * scale)
    im = Image.new("RGB", (W, H), (255, 255, 255))
    d = ImageDraw.Draw(im)
    for shape in sl.shapes:
        try:
            _shape(d, im, shape, scale)
        except Exception:
            continue
    return im

def render_to_file(pptx_path, page=1, out=None):
    im = render(pptx_path, page)
    if im is None:
        return None
    out = out or f"/tmp/_render_p{page}.png"
    im.save(out)
    return out
