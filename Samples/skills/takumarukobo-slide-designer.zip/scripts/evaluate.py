# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""Hybrid slide evaluator (C).

Two layers, by design:
  1. INTERPRETABLE GATE (this script, transparent numbers): renders the pptx to
     an image and scores the *coarse substance & readability* axis with a learned
     logistic model on interpretable image features (assets/image_model.json):
     is it filled enough, drawn-in enough, readable (contrast), balanced — vs
     empty / sparse / faint. Returns p_coarse + concrete fixable feedback.
  2. VISION JUDGEMENT (done by the calling vision model, e.g. GPT-5.5): looks at
     the rendered image and rates STRUCTURE / READABILITY / MEANING — the semantic
     quality that pixel statistics cannot capture (a dense but unstructured text
     wall must be rejected here even though it passes the gate).

Final: a slide is GOOD only if the gate passes AND the vision judgement passes.

Usage:
  python evaluate.py deck.pptx                 # gate + render images + vision rubric
  python evaluate.py deck.pptx --vision v.json # combine gate with vision scores
     v.json = {"1":{"structured":0.9,"readable":0.9,"meaningful":0.8}, "2":{...}}
"""
import sys, os, json, math
import image_features as IF

GATE = 0.5          # coarse gate threshold
VIS  = 0.6          # each vision sub-score must reach this

def load_model():
    return json.load(open(os.path.join(os.path.dirname(__file__), "..", "assets",
                                        "image_model.json"), encoding="utf-8"))

def p_coarse(feat, M):
    z = M["b"]
    for i, k in enumerate(M["keys"]):
        z += M["w"][i] * ((feat.get(k, 0) - M["mu"][i]) / M["sd"][i])
    return 1.0 / (1.0 + math.exp(-max(-30, min(30, z))))

def gate_feedback(f):
    t = []
    if f["whitespace_max"] > 0.18: t.append(f"大きな空白({f['whitespace_max']:.0%})→図・要素で埋める")
    if f["ink_coverage"] < 0.22:   t.append(f"内容が薄い(被覆{f['ink_coverage']:.0%})→情報を増やす")
    if f["edge_density"] < 0.11:   t.append(f"描き込み不足(edge {f['edge_density']:.2f})→チャート/アイコン/図解を足す")
    if f["contrast"] < 0.45:       t.append("コントラスト不足→明度差を上げる")
    if f["balance"] < 0.80:        t.append("視覚バランスの偏り→重心を整える")
    return t

RUBRIC = ("""── 視覚判定（GPT-5.5 が各スライドのレンダリング画像を見て 0〜1 で採点）──
  structured : 情報がグループ化・階層化され、区画/見出しで読み解ける（テキストの壁・雑然は低い）
  readable   : 文字サイズ・余白・コントラストが適切で無理なく読める
  meaningful : チャート/アイコン/関係図など「図で意味」を示している（飾りでない）
 → 3項目すべて {vis:.1f} 以上で視覚判定パス。v.json に {{"slide":{{...}}}} で渡し --vision で最終判定。""")

def evaluate(pptx, vision=None, outdir="/tmp/slide_eval", images=None):
    from pptx import Presentation
    os.makedirs(outdir, exist_ok=True)
    M = load_model()
    if images is not None:                      # pre-rendered PNGs (no LibreOffice)
        pages = [(i + 1, p) for i, p in enumerate(images)]
    else:
        total = len(list(Presentation(pptx).slides))
        pages = [(pg, None) for pg in range(1, total + 1)]
    total = len(pages)
    print(f"DECK: {pptx or images}   ハイブリッド評価（門番 p≥{GATE} ＋ 視覚判定 各≥{VIS}）\n")
    n_good = 0
    for pg, imgpath in pages:
        if imgpath is not None:
            img = imgpath
        else:
            try:
                img = IF.render_pptx_page(pptx, pg)
            except FileNotFoundError:
                print("⚠ LibreOffice / pdftoppm が見つかりません。\n"
                      "  → `apt-get install -y libreoffice poppler-utils` を入れるか、\n"
                      "  → 各スライドをPNG化して `--images 画像フォルダ` で渡してください。")
                return
        f = IF.extract_image(img) if img else None
        if f is None:
            print(f"[S{pg}] レンダリング失敗"); continue
        dst = os.path.join(outdir, f"S{pg}.png")
        try: __import__("shutil").copy(img, dst)
        except Exception: dst = img
        pc = p_coarse(f, M); gate_ok = pc >= GATE
        line = (f"[S{pg}] 門番 {pc*100:4.0f}/100 {'✓' if gate_ok else '✗'}  "
                f"(edge {f['edge_density']:.2f} 空白 {f['whitespace_max']:.2f} "
                f"被覆 {f['ink_coverage']:.2f} 可読 {f['contrast']:.2f})")
        if vision is not None:
            v = vision.get(str(pg), {})
            vs = [v.get("structured", 0), v.get("readable", 0), v.get("meaningful", 0)]
            vis_ok = min(vs) >= VIS
            good = gate_ok and vis_ok
            n_good += int(good)
            print(line + f"  視覚[構造{vs[0]:.1f}/可読{vs[1]:.1f}/意味{vs[2]:.1f}] "
                  f"{'✓' if vis_ok else '✗'} → {'✅良い' if good else '❌不採用'}")
            if not gate_ok:
                for t in gate_feedback(f): print("        →(門番) " + t)
            if not vis_ok:
                lab = ["構造", "可読", "意味"]
                low = [lab[i] for i, s in enumerate(vs) if s < VIS]
                print("        →(視覚) " + "・".join(low) + " が不足：グループ化/見出し/図解で"
                      "意味を構造化して見せる（テキストの壁・雑然を避ける）")
        else:
            print(line + f"  画像→ {dst}")
            if not gate_ok:
                for t in gate_feedback(f): print("        → " + t)
    if vision is None:
        print(RUBRIC.format(vis=VIS))
        print("\n※ 門番は『実質・可読』の粗い判定のみ。『構造化・意味』は必ず視覚判定で確認すること。")
    else:
        print(f"\n良い {n_good}/{total}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python evaluate.py deck.pptx [--vision v.json]\n"
              "   or: python evaluate.py --images <dir-of-PNGs> [--vision v.json]"
              "  (no LibreOffice needed)")
        sys.exit(1)
    vis = None
    if "--vision" in sys.argv:
        vis = json.load(open(sys.argv[sys.argv.index("--vision") + 1], encoding="utf-8"))
    if "--images" in sys.argv:
        d = sys.argv[sys.argv.index("--images") + 1]
        imgs = ([os.path.join(d, x) for x in sorted(os.listdir(d))
                 if x.lower().endswith((".png", ".jpg", ".jpeg"))] if os.path.isdir(d)
                else [d])
        evaluate(None, vision=vis, images=imgs)
    else:
        evaluate(sys.argv[1], vision=vis)
