# takumarukobo-slide-designer
# Author: TAKUMARU工房
"""Template-free entry point. Input = free-composition spec (see free_engine.py).
No layouts/themes/chrome. Generate freely, then judge with evaluate.py."""
from __future__ import annotations
import argparse, json, sys
from free_engine import build

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    spec = json.load(open(args.input, encoding="utf-8"))
    n = build(spec, args.output)
    print(f"Deck written: {args.output} ({n} slides, free composition)")

if __name__ == "__main__":
    main()
